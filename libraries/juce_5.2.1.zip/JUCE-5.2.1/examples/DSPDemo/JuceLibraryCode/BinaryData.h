/* =========================================================================================

   This is an auto-generated file: Any edits you make may be overwritten!

*/

#pragma once

namespace BinaryData
{
    extern const char*   cassette_recorder_wav;
    const int            cassette_recorder_wavSize = 37902;

    extern const char*   EditorColourScheme_xml;
    const int            EditorColourScheme_xmlSize = 628;

    extern const char*   guitar_amp_wav;
    const int            guitar_amp_wavSize = 90246;

    extern const char*   ConvolutionDemo_cpp;
    const int            ConvolutionDemo_cppSize = 3007;

    extern const char*   FIRFilterDemo_cpp;
    const int            FIRFilterDemo_cppSize = 2674;

    extern const char*   GainDemo_cpp;
    const int            GainDemo_cppSize = 1809;

    extern const char*   IIRFilterDemo_cpp;
    const int            IIRFilterDemo_cppSize = 2819;

    extern const char*   OscillatorDemo_cpp;
    const int            OscillatorDemo_cppSize = 3986;

    extern const char*   OverdriveDemo_cpp;
    const int            OverdriveDemo_cppSize = 3039;

    extern const char*   SIMDRegisterDemo_cpp;
    const int            SIMDRegisterDemo_cppSize = 4849;

    extern const char*   StateVariableFilterDemo_cpp;
    const int            StateVariableFilterDemo_cppSize = 2731;

    extern const char*   WaveShaperTanhDemo_cpp;
    const int            WaveShaperTanhDemo_cppSize = 2037;

    // Points to the start of a list of resource names.
    extern const char* namedResourceList[];

    // Number of elements in the namedResourceList array.
    const int namedResourceListSize = 12;

    // If you provide the name of one of the binary resource variables above, this function will
    // return the corresponding data and its size (or a null pointer if the name isn't found).
    const char* getNamedResource (const char* resourceNameUTF8, int& dataSizeInBytes) throw();
}
